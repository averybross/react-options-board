/* eslint-disable */
import React from 'react';
import { storiesOf } from '@storybook/react';
import OptionsBoardTableHead from './OptionsBoardTableHead';
import { Booktop } from '../OptionsBoard/OptionsBoard';

storiesOf('OptionsBoardTableHead', module).add('default', () => <OptionsBoardTableHead />);
