/* eslint-disable */
import React from 'react';
import { storiesOf } from '@storybook/react';
import OptionsBoard from './OptionsBoard';
import { ContractsStore } from '../../stores/ContractsStore';

storiesOf('OptionsBoard', module).add('default', () => <OptionsBoard />);
