/* eslint-disable */
import React from 'react';
import { storiesOf } from '@storybook/react';
import StrikePriceChart from './StrikePriceChart';

storiesOf('StrikePriceChart', module).add('default', () => <StrikePriceChart />);
